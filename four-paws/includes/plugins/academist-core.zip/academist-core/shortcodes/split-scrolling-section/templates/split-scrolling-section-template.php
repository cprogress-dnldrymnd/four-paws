<div class="eltdf-split-scrolling-section">
    <?php echo do_shortcode($content); ?>
</div>