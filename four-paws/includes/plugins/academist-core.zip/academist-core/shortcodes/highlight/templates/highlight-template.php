<?php
/**
 * Highlight shortcode template
 */
?>

<span class="eltdf-highlight" <?php academist_elated_inline_style($highlight_style);?>>
	<?php echo esc_html($content);?>
</span>