<?php

include_once ACADEMIST_CORE_ABS_PATH . '/core-dashboard/sub-pages/import/import-page.php';
include_once ACADEMIST_CORE_ABS_PATH . '/core-dashboard/sub-pages/import/import.php';