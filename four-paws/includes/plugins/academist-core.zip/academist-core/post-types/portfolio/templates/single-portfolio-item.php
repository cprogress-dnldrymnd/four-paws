<?php

get_header();

academist_elated_get_title();

do_action('academist_elated_action_before_main_content');

academist_core_get_single_portfolio();

get_footer();