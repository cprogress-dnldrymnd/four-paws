<div class="eltdf-team-single-content">
	<?php the_content(); ?>
</div>