<?php

include_once ACADEMIST_LMS_ABS_PATH . '/widgets/course-features-widget/functions.php';
include_once ACADEMIST_LMS_ABS_PATH . '/widgets/course-features-widget/course-features.php';