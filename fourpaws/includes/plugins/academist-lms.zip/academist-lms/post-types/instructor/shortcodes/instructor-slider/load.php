<?php

include_once 'instructor-slider.php';
include_once 'helper-functions.php';
