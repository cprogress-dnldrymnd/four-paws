<?php if ( ! empty( $phone ) ) { ?>
	<div class="eltdf-ts-info-row">
		<span aria-hidden="true" class="icon_phone eltdf-ts-bio-icon"></span>
		<span class="eltdf-ts-bio-info"><?php echo esc_html__( 'phone: ', 'academist-lms' ) . esc_html( $phone ); ?></span>
	</div>
<?php } ?>