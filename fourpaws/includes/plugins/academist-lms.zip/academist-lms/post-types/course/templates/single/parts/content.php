<div class="eltdf-course-content">
	<h3 class="eltdf-course-content-title"><?php esc_html_e( 'About this course', 'academist-lms' ) ?></h3>
	<?php the_content(); ?>
</div>