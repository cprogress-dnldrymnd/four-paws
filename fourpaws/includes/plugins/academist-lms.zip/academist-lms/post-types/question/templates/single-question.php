<?php

get_header();

academist_elated_get_title();

academist_lms_get_single_question();

get_footer();