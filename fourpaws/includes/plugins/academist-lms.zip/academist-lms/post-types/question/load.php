<?php

include_once ACADEMIST_LMS_CPT_PATH . '/question/question-register.php';
include_once ACADEMIST_LMS_CPT_PATH . '/question/helper-functions.php';