<?php

include_once ACADEMIST_MEMBERSHIP_SHORTCODES_PATH . '/register/functions.php';
include_once ACADEMIST_MEMBERSHIP_SHORTCODES_PATH . '/register/register.php';