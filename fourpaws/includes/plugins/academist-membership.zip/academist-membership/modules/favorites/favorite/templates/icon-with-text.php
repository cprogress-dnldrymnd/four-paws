<a href="javascript:void(0)" class="eltdf-membership-item-favorites" data-item-id="<?php echo esc_attr($item_id); ?>">
    <i class="eltdf-favorites-icon fa <?php echo esc_attr( $icon ); ?>"></i>
</a>
